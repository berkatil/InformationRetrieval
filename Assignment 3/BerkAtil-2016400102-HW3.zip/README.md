# InformationRetrieval - Assignment 2-3

The system requires to install python3. The program can take 2 different kinds of arguments. One of them is for building the recommendation system and the other one is for getting the recommendations

1.  In order to build the system, txt file consisting of list of urls of the books must be given and its command is the following: python3 recommender.py file_path

- file_path is a path to a file containing books.

2. In order to recieve the recommendations, a url of a book must be given as a parameter and it should not contain ".txt" in the url. The command for this is the following: python3 recommender.py book_url