# InformationRetrieval - Assignment 1

The program takes its two inputs via command line arguments. It requires to install python3. You can use the following command to run the program:

python3 assignment1.py input_string_1 input_string_2, For example, python3 assignment1.py berk kreb.

Note that if you would like to give a string containing space, you should give it in "". For example, python3 assignment1 "ssad " " asd"

After you run it, you will see distance between them, edit table and required operations to transform first string into the second one for both Levenshtein and Damerau-Levenshtein algorithms.
